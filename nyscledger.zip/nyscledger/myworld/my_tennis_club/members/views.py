from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
from .form import *
from .models import *

from django.contrib.auth.forms import UserCreationForm
#logn here
from django.contrib.auth import authenticate, login, logout
# Create your views here.

def members(request):
	if request.method == 'GET':
		form = LoginForm()
		return render(request,'index.html', {'form': form})
	elif (request.method == 'POST'):
		username = request.POST.get('username')
		password = request.POST.get('password')

		user = authenticate(request, username=username, password=password)
			
			

		if user is not None:
			login(request, user)
			# h= request.user.courses
			return redirect('/dashboard/')
		else:
			messages.info(request, 'Username or password is incorrect!')
	form = LoginForm()
	
	return render(request, 'index.html', {'form': form})


def register(request):
	# context = {}
	if request.method == "POST":
		form = corpReg(request.POST, request.FILES)
		if form.is_valid:
			register = form.save(commit=False)
			register.save()
		messages.success(request, 'Registration Successful')
	else:
		form = corpReg()
	messages.error(request, 'Registration Failed')
	return render(request, 'register.html', {'form':form})

# @unauthenticated_user
def adminReg(request):
	form = RegisterForm()
	if request.method == 'POST':
		form = UserCreationForm(request.POST)
		if form.is_valid():
			user=form.save()
			username = form.cleaned_data.get('username')
			# group = Group.objects.get(name='student')
			# user.groups.add(group)
			# Student.objects.create(
			# 	user=user
			# )
	context = {'form':form}
	return render(request, 'adminReg.html', context)

# @unauthenticated_user

def dashboard(request):
	return render(request, 'dasboard.html')




