from django.urls import path
from . import views


urlpatterns =[   
	path('nyscledger/', views.members, name='members'),
	path('nyscledger/register/', views.register, name='register'),
	path('nyscledger/adminReg/', views.adminReg, name='adminReg'),
	path('nyscledger/dashboard/', views.adminReg, name='adminReg'),
	
]