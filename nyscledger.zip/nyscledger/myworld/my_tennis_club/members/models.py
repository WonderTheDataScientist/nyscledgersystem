from django.db import models

# Create your models here.

class CorpRegister(models.Model):
	postCds  = (
		('Excos','Excos'),
		('Member','Member')
	)
	firstname = models.CharField(verbose_name="First Name", max_length=100, null=False, blank=False)
	lastname = models.CharField(verbose_name="Last Name", max_length=100, null=False, blank=False)
	statecode = models.CharField(verbose_name="State Code", max_length=100, null=False, blank=False)
	sor = models.CharField(verbose_name="State of Origin", max_length=100, null=False, blank=False)
	statedeployed = models.CharField(verbose_name="State Deployed", max_length=100, null=False, blank=False)
	cds = models.CharField(verbose_name="CDS", max_length=100, null=False, blank=False)
	pcds = models.CharField(verbose_name="Post in CDS", max_length=100, null=False, blank=False, choices=postCds)
	# pcds = models.CharField(verbose_name="Post in CDS", max_length=100, null=False, blank=False)
	phone = models.CharField(verbose_name="Phone Number", max_length=100, null=False, blank=False)
	profile = models.ImageField(verbose_name="Profile Picture", blank=True)


	def __str__(self):
		return self.firstname + ' ' + self.lastname